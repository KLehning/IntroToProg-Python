# ------------------------------------------------- #
# Title: To Do List Script
# Dev:   Kyle Lehning
# Date:  Oct 29, 2018
# ChangeLog: (Who, When, What)
#   Lehning - New script - 10/29/18
# ------------------------------------------------- #
# -- Data -- #
exitProgram = False
CLASS_FOLDER = "C:\\Users\\lehni\\Documents\\Education\\UW\\Python\\Foundations_of_Programming_Python\\"
MODULE_FOLDER = "Module05\\Assignment05\\"
TO_DO_NAME = "ToDo.txt"
TO_DO_DOC = CLASS_FOLDER + MODULE_FOLDER + TO_DO_NAME
try:
    objToDoFile = open(TO_DO_DOC, "r+")
except:
    print("Exiting, please ensure ", TO_DO_NAME, " exists at: ", CLASS_FOLDER, MODULE_FOLDER)
    import sys
    sys.exit()
toDoDict = {}
toDoList = []


# -- Processing -- #
# Read all lines from file into a list of dictionary items per line split by comma
for line in objToDoFile.readlines():
    keyedLine = line.rstrip("\n\r").split(",")  # rstrip to remove new lines that are read from file
    toDoDict = {keyedLine[0]: keyedLine[1]}
    toDoList += [toDoDict]


def add_new(passed_list):
    """adds to the list"""
    new_thing_to_do = {thingToDo: importance}
    passed_list += [new_thing_to_do]


def remove_existing():
    """removes an existing item from the list"""
    # return is used to return a string about what the function did which the caller can then act upon
    try:
        removed_item = toDoList.pop(int(removalIndex))
        (k, v), = removed_item.items()
        return k + " has been removed"
    except:
        return "THE REMOVAL FAILED"


def save_data(open_file):
    """saves back to TO_DO_DOC"""
    for listItem in toDoList:
        (k, v), = listItem.items()
        open_file.write(k + "," + v)


def delete_file_content(open_file):
    open_file.seek(0)
    open_file.truncate()


# -- Presentation (Input/Output) -- #
def show_data():
    """shows data of list to console"""
    print("INDEX\t:\t THING TO DO \t:\t IMPORTANCE")
    for idx, item in enumerate(toDoList):  # use loop so each item on it's own line and can print index
        (k, v), = item.items()
        print(idx, "\t\t:\t", k, "\t:\t", v)
    print()


while exitProgram is False:
    # Print the menu of options
    print("""\tMenu of Options
    1) Show current data.
    2) Add a new item.
    3) Remove an existing item.
    4) Save data to file.
    5) Exit program.""")
    selItem = input("SELECTION: ")
    # If statement handles whichever option user input
    if selItem == "1":
        show_data()
    elif selItem == "2":
        thingToDo = input("What needs to be done: ")
        importance = input("How important is this?: ")
        print("ITEM ADDED \n")
        add_new(toDoList)
    elif selItem == "3":
        show_data()  # this allows the user to see index for ease of removal
        removalIndex = input("PROVIDE THE INDEX OF THE ITEM YOU WISH TO REMOVE: ")
        removeLine = remove_existing()
        print(removeLine)
    elif selItem == "4":
        delete_file_content(objToDoFile)
        save_data(objToDoFile)
        print("LIST SAVED TO " + TO_DO_DOC + "\n")
    elif selItem == "5":
        exitProgram = True
    else:
        print("PLEASE PROVIDE A VALID OPTION \n")
objToDoFile.close()
print("PROGRAM SUCCESSFULLY EXITED")

