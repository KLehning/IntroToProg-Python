# ------------------------------------------------- #
# Title: Exception Handling Example
# Dev:   Kyle Lehning
# Date:  Nov 14, 2018
# ChangeLog: (Who, When, What)
#   Lehning - New script - 11/14/18
# ------------------------------------------------- #
MyFile = "C:\\Users\\lehni\\Desktop\\NonExistentFile.txt"  # Location of a file that in this case doesn't exist
theFile = None
listOfLines = []  # List that would be added to if file existed

try:
    theFile = open(MyFile, "r")  # Try to open the non existent file to read
except IOError:
    print("Unfortunately ", MyFile, " doesn't exist")
except Exception as e:  # Would only reach here if there was some sort of error opening the file other than not existing
    print("There was an unknown issue opening ", MyFile)
    print("Python error: ", e)

# If the file existed then theFile would not be None and processing could occur
if theFile is not None:
    for line in theFile.readlines():
        listOfLines.append(line)
else:
    print("Since there was an error opening the file it could not be read")
