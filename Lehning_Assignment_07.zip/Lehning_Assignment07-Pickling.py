# ------------------------------------------------- #
# Title: Pickling Script
# Dev:   Kyle Lehning
# Date:  Nov 14, 2018
# ChangeLog: (Who, When, What)
#   Lehning - New script - 11/14/18
# ------------------------------------------------- #

import pickle
movieList = []
movieFile = open("Movies.dat", "ab+")  # open byte file for read/write, create if doesn't exist
movieFile.seek(0)  # Go to beginning of file since a will open at the end for appending
try:
    movieList = pickle.load(movieFile)
except EOFError:  # Error if nothing currently pickled
    print("No current movies in list")
while True:
    movie = input("Enter a movie to add to your list, n to exit: ")
    if movie == "n":
        break
    movieList.append(movie)
movieFile.truncate()  # Delete anything previously pickled in file
pickle.dump(movieList, movieFile)
movieFile.close()

displayMovie = input("Enter y to see your movie list: ")
if displayMovie == "y":
    movieFile = open("Movies.dat", "rb")
    movieData = pickle.load(movieFile)
    movieFile.close()
    print(movieData)
